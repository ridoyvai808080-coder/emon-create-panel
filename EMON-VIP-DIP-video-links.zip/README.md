# EMON VIP DIP — GitHub Pages

এই প্যাকেজে আপনার দেওয়া APK (`EMON-VIP-DIP.apk`) সহ সম্পূর্ণ static website আছে।

## Files
- `index.html`
- `style.css`
- `script.js`
- `EMON-VIP-DIP.apk`

## GitHub Pages
1. GitHub-এ নতুন repository তৈরি করুন।
2. এই চারটি file upload করুন।
3. Settings → Pages → Deploy from branch → `main` → `/ (root)` নির্বাচন করুন।
4. Save করে কয়েক মিনিট অপেক্ষা করুন।

Download button একই repository-র `EMON-VIP-DIP.apk` ফাইল ডাউনলোড করবে।

## Important
এই website Gmail/Google password নেয় না। Gmail/phone field শুধু browser-side format verification করে। কোনো real login দরকার হলে official OAuth ব্যবহার করা উচিত।
